package org.yourorghere;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;

public class Tree_JOGL implements GLEventListener {

    private float angle = 0.0f;

    public static void main(String[] args) {
        
        // Create a window frame for the 3D scene
        Frame frame = new Frame("3D Tree JOGL");
        GLCanvas canvas = new GLCanvas();

        // Attach the OpenGL event listener
        canvas.addGLEventListener(new Tree_JOGL());
        frame.add(canvas);
        frame.setSize(640, 480);
        final Animator animator = new Animator(canvas);

        // Close the window gracefully
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new Thread(new Runnable() {
                    public void run() {
                        animator.stop();  // Stop the animator thread
                        System.exit(0);    // Exit the program
                    }
                }).start();
            }
        });

        frame.setLocationRelativeTo(null); // Center the window
        frame.setVisible(true);
        animator.start();  // Start the animation loop
    }

    public void init(GLAutoDrawable drawable) {
        
        GL gl = drawable.getGL();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        gl.setSwapInterval(1); // Set swap interval for smoother rendering

        // Set the background color (gray)
        gl.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);

        gl.glEnable(GL.GL_DEPTH_TEST);  // Enable depth testing for proper rendering
        gl.glShadeModel(GL.GL_SMOOTH);   // Smooth shading for better appearance

        // Enable lighting
        gl.glEnable(GL.GL_LIGHTING);
        gl.glEnable(GL.GL_LIGHT0);  // Enable the primary light source

        // Set up ambient light (soft lighting for the whole scene)
        float[] ambientLight = {0.2f, 0.2f, 0.2f, 1.0f};
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, ambientLight, 0);

        // Set up main light position and color (white light)
        float[] lightPos = {0.0f, 5.0f, 10.0f, 1.0f};
        float[] lightColor = {1.0f, 1.0f, 1.0f, 1.0f};
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, lightPos, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, lightColor, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, lightColor, 0);

        // Set up specular highlights (shiny surfaces)
        float[] specularLight = {1.0f, 1.0f, 1.0f, 1.0f};
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, specularLight, 0);

        // Enable material properties for lighting
        gl.glEnable(GL.GL_COLOR_MATERIAL);
        gl.glColorMaterial(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE);
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        // Prevent division by zero if the height is zero
        if (height <= 0) {
            height = 1;
        }

        // Set the viewport and aspect ratio based on the window size
        float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 1.0, 50.0);  // Perspective projection for 3D effect
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        
        GL gl = drawable.getGL();
        GLUT glut = new GLUT();

        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);  // Clear the screen and depth buffer
        gl.glLoadIdentity();  // Reset modelview matrix

        // Move the camera to get a better view of the tree
        gl.glTranslatef(0.0f, -3.0f, -18.0f);  // Camera moved slightly forward

        // Apply rotation to the whole scene for dynamic effect
        gl.glRotatef(angle, 0.0f, 1.0f, 0.0f);  // Rotate around the Y-axis
        angle += 0.5f;  // Increment the rotation angle

        // === Drawing the trunk (brown cylinder) ===
        gl.glPushMatrix();
        gl.glColor3f(0.36f, 0.20f, 0.09f);  // Dark brown color for the trunk
        gl.glTranslatef(0.0f, 2.0f, 0.0f);  // Move the trunk up
        gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  // Rotate to make the cylinder vertical
        glut.glutSolidCylinder(0.5, 4.0, 20, 20);  // Draw the trunk (radius, height, slices, stacks)
        gl.glPopMatrix();

        // === Drawing branches (small cylinders) ===
        gl.glColor3f(0.3f, 0.15f, 0.05f);  // Lighter brown for the branches

        // Draw the first branch
        gl.glPushMatrix();
        gl.glTranslatef(0.8f, 4.5f, 0.0f);  // Move branch slightly to the left
        gl.glRotatef(30.0f, 0.0f, 0.0f, 1.0f);  // Rotate the branch
        gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  // Vertical orientation
        glut.glutSolidCylinder(0.2, 3.0, 10, 10);  // Draw the first branch (radius, height)
        gl.glPopMatrix();

        // Draw the second branch
        gl.glPushMatrix();
        gl.glTranslatef(-0.8f, 4.5f, 0.0f);  // Move branch to the right
        gl.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);  // Rotate the branch
        gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  // Vertical orientation
        glut.glutSolidCylinder(0.2, 3.0, 10, 10);  // Draw the second branch (radius, height)
        gl.glPopMatrix();

        // === Drawing leaves (cone shapes) ===
        gl.glColor3f(0.0f, 0.6f, 0.0f);  // Green color for the leaves

        float yOffset = 5.0f;
        for (int i = 0; i < 3; i++) {
            gl.glPushMatrix();
            gl.glTranslatef(0.0f, yOffset, 0.0f);  // Move each layer upwards
            gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  // Rotate for cone orientation
            glut.glutSolidCone(2.0f - i * 0.5f, 2.0f, 20, 20);  // Draw cone with decreasing size upwards
            gl.glPopMatrix();
            yOffset += 1.2f;  // Adjust position for the next layer
        }

        // === Adding shadows on the ground to create a 3D effect ===
        gl.glPushMatrix();
        gl.glTranslatef(0.0f, -10.0f, 0.0f);  // Move the shadow down to the ground
        gl.glColor3f(0.2f, 0.2f, 0.2f);  // Dark gray color for the shadow
        glut.glutSolidSphere(0.5f, 20, 20);  // Draw a simple shadow using a sphere
        gl.glPopMatrix();

        gl.glFlush();  // Force the OpenGL pipeline to process the drawing
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
}