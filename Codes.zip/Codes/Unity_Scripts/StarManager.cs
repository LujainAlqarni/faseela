using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class StarManager : MonoBehaviour
{
    public Image[] stars;
    public GameObject starCanvas;
    public Sprite emptyStarSprite;
    public Sprite fullStarSprite;
    public AudioSource starSound;
    public bool starGranted = false;
    private int currentStar = 0;
    private static bool exists = false;
  

    private void Start()
    {
        UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void Awake()
    {
        if (exists)
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

        if(starCanvas != null)
            DontDestroyOnLoad(starCanvas);
        exists = true;
    }

    private void OnDisable()
    {
        UnityEngine.SceneManagement.SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "Cleaning" || scene.name == "Planting" || scene.name == "Watering")
    {
            starCanvas.SetActive(true);
            starGranted = false;
        }
    else
        {
            starCanvas.SetActive(false);
        }
    }

    public void GrantStar()
    {
        if (starGranted)
            return;

        if (currentStar < stars.Length)
        {
            stars[currentStar].sprite = fullStarSprite;
            StartCoroutine(AnimateStar(stars[currentStar]));

            if (starSound != null)
                starSound.Play();

            currentStar++;
        }

        starGranted = true;
    }

    IEnumerator AnimateStar(Image star)
    {
        Vector3 originalScale = star.rectTransform.localScale;
        Vector3 targetScale = originalScale * 1.6f;
        float durationUp = 0.3f;
        float durationDown = 0.5f;

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / durationUp;
            float scaleT = Mathf.Sin(t * Mathf.PI * 0.5f);
            star.rectTransform.localScale = Vector3.Lerp(originalScale, targetScale, scaleT);
            yield return null;
        }

        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / durationDown;
            float scaleT = 1f - Mathf.Cos(t * Mathf.PI * 0.5f);
            star.rectTransform.localScale = Vector3.Lerp(targetScale, originalScale, scaleT);
            yield return null;
        }

        star.rectTransform.localScale = originalScale;
    }
}
