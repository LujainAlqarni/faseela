using UnityEngine;
using System.Collections;

public class TreeGrowthController : MonoBehaviour
{
    public GameObject[] growthStages;
    public float growthInterval = 3f;

    void Start()
    {
        foreach (GameObject stage in growthStages)
        {
            stage.SetActive(false);
        }
    }

    public IEnumerator GrowTree()
    {
        for (int i = 0; i < growthStages.Length; i++)
        {
            if (i > 0)
                growthStages[i - 1].SetActive(false);

            growthStages[i].SetActive(true);

            if (i < growthStages.Length - 1)
                yield return new WaitForSeconds(growthInterval);
        }
    }
}

