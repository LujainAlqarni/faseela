﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class TeapotController : MonoBehaviour
{
    public Transform targetPoint;
    public float moveSpeed = 2f;
    public float rotateAmount = 30f;
    public float waitAfterGrowth = 1f;
    public TreeGrowthController treeGrowth;
    public ParticleSystem waterParticles;
    public AudioSource waterSound;
    private StarManager starManager;
    private Vector3 originalPosition;
    private Quaternion originalRotation;
    private bool isMoving = false;

    void Start()
    {
        originalPosition = transform.position;
        originalRotation = transform.rotation;
        starManager = FindObjectOfType<StarManager>();
    }

    void OnMouseDown()
    {
        if (!isMoving)
            StartCoroutine(MoveAndWaitForTree());
    }

    IEnumerator MoveAndWaitForTree()
    {
        isMoving = true;

        Quaternion startRotation = transform.rotation;

        yield return MoveTo(targetPoint.position, transform.rotation);

        float tiltAmount = -30f;
        Quaternion tiltRotation = Quaternion.Euler(0f, 0f, tiltAmount) * startRotation;
        yield return RotateTo(tiltRotation);

        waterParticles.Play();
        yield return new WaitForSeconds(0.5f);
        waterSound.Play();

        yield return StartCoroutine(treeGrowth.GrowTree());

        waterParticles.Stop();
        yield return new WaitForSeconds(1.5f);
        waterSound.Stop();

        yield return RotateTo(startRotation);

        yield return MoveTo(originalPosition, originalRotation);

        if (starManager != null)
            starManager.GrantStar();

        StartCoroutine(LoadNextScene("FifthCon"));

        isMoving = false;
    }

    IEnumerator MoveTo(Vector3 targetPos, Quaternion targetRot)
    {
        while (Vector3.Distance(transform.position, targetPos) > 0.01f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);
            yield return null;
        }
    }

    IEnumerator RotateTo(Quaternion targetRot)
    {
        while (Quaternion.Angle(transform.rotation, targetRot) > 0.5f)
        {
            transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRot, 100 * Time.deltaTime);
            yield return null;
        }
    }

    IEnumerator LoadNextScene(string sceneName)
    {
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }
}