﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ObjectRemover : MonoBehaviour
{
    private int totalRemovables = 8;
    private int removedCount = 0;

    void Update()
    {
        if (!SelectFork.toolActivated)
            return;

        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, 100f))
            {
                if (hit.collider.CompareTag("Removable"))
                {
                    Destroy(hit.collider.gameObject);
                    removedCount++;

                    if (removedCount >= totalRemovables)
                    {
                        FindObjectOfType<StarManager>().GrantStar();

                        StartCoroutine(LoadNextScene("ThirdCon"));

                    }
                }
            }
        }
    }

    IEnumerator LoadNextScene(string sceneName)
    {
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }
}