﻿using UnityEngine;
using UnityEngine.Audio;

public class SelectFork : MonoBehaviour
{
    private Vector3 originalScale;
    public float scaleMultiplier = 1.1f;
    public static bool toolActivated = false;
    public AudioSource forkSound;

    void Start()
    {
        originalScale = transform.localScale;
    }

    private void OnMouseDown()
    {
        transform.localScale = originalScale * scaleMultiplier;
        toolActivated = true;
        forkSound.Play();
    }

    public void ResetTool()
    {
        transform.localScale = originalScale;
        toolActivated = false;
    }
}
