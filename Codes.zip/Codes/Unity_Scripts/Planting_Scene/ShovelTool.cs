﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class ShovelTool : MonoBehaviour
{
    public static int step = 0;
    public GameObject groundNormalPrefab;
    public GameObject groundDugPrefab;
    public GameObject groundAfterDugPrefab;
    public AudioClip digSound;
    public float scaleMultiplier = 1.2f;
    private Vector3 originalScale;
    private GameObject currentGround;
    private int clickCount = 0;
    private Vector3 groundPosition = new Vector3(-6.291511f, -0.35f, -14.3645f);
    private AudioSource audioSource;
    private StarManager starManager;

    void Start()
    {
        originalScale = transform.localScale;

        audioSource = GetComponent<AudioSource>();

        if (groundNormalPrefab == null)
        {
            return;
        }

        currentGround = Instantiate(groundNormalPrefab, groundPosition, Quaternion.identity);

        starManager = FindObjectOfType<StarManager>();
    }

    private void OnMouseDown()
    {
        if (step != 0 && step != 3) return;

        transform.localScale = originalScale * scaleMultiplier;

        Vector3 pos = groundPosition;
        Quaternion rot = Quaternion.identity;

        Destroy(currentGround);

        if (clickCount == 0)
        {
            currentGround = Instantiate(groundDugPrefab, pos, rot);
        }
        else if (clickCount == 1)
        {
            currentGround = Instantiate(groundAfterDugPrefab, pos, rot);

            if (starManager != null)
                StartCoroutine(DelayedGrantStar());

            StartCoroutine(LoadNextScene("FourthCon"));

        }
        else
        {
            currentGround = Instantiate(groundNormalPrefab, pos, rot);
            clickCount = -1;
        }

        clickCount++;

        if (digSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(digSound);
        }

        Invoke(nameof(ResetScale), 0.5f);

        step++;
    }

    void ResetScale()
    {
        transform.localScale = originalScale;
    }

    IEnumerator DelayedGrantStar()
    {
        yield return new WaitForSeconds(1f);
        starManager.GrantStar();
    }

    IEnumerator LoadNextScene(string sceneName)
    {
        yield return new WaitForSeconds(2.3f);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }
}
