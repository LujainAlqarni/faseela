﻿using UnityEngine;
using System.Collections;

public class FR : MonoBehaviour
{
    public Transform dropZoneTarget;
    public Transform spawnPoint;
    public GameObject fertilizerPrefab;
    public int fertilizerCount = 20;
    public float moveSpeed = 2f;
    public float rotationAmount = 180f;
    public float rotationSpeed = 90f;
    public AudioSource fertilizerSound;
    private bool isBusy = false;
    private Vector3 originalPosition;
    private Quaternion originalRotation;

    void Start()
    {
        originalPosition = transform.position;
        originalRotation = transform.rotation;
    }

    void OnMouseDown()
    {
        if (ShovelTool.step != 2) return;

        if (!isBusy)
        {
            StartCoroutine(HandleFertilizerDropSequence());
            ShovelTool.step++;
        }
    }

    IEnumerator HandleFertilizerDropSequence()
    {
        isBusy = true;

        while (Vector3.Distance(transform.position, dropZoneTarget.position) > 0.01f)
        {
            transform.position = Vector3.MoveTowards(transform.position, dropZoneTarget.position, moveSpeed * Time.deltaTime);
            yield return null;
        }

        Quaternion startRot = transform.rotation;
        Quaternion targetRot = transform.rotation * Quaternion.Euler(0f, rotationAmount, 0f);

        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * (rotationSpeed / 90f);
            transform.rotation = Quaternion.Slerp(startRot, targetRot, t);
            yield return null;
        }

        yield return new WaitForSeconds(0.5f);
        fertilizerSound.Play();

        for (int i = 0; i < fertilizerCount; i++)
        {
            Vector3 offset = new Vector3(Random.Range(-0.1f, 0.1f), 0, Random.Range(-0.1f, 0.1f));
            GameObject fertilizer = Instantiate(fertilizerPrefab, spawnPoint.position + offset, Quaternion.identity);

            Rigidbody rb = fertilizer.GetComponent<Rigidbody>();
            if (rb != null)
            {
                Vector3 randomForce = new Vector3(Random.Range(-1f, 1f), -1f, Random.Range(-1f, 1f));
                rb.AddForce(randomForce * 2f, ForceMode.Impulse);
            }

            yield return new WaitForSeconds(0.1f);
        }

        yield return new WaitForSeconds(0.5f);
        fertilizerSound.Stop();

        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * (rotationSpeed / 90f);
            transform.rotation = Quaternion.Slerp(transform.rotation, originalRotation, t);
            yield return null;
        }

        while (Vector3.Distance(transform.position, originalPosition) > 0.01f)
        {
            transform.position = Vector3.MoveTowards(transform.position, originalPosition, moveSpeed * Time.deltaTime);
            yield return null;
        }

        isBusy = false;
    }
}
